/*
 * menu_defaults.js
 */

var menu_defaults = {
	disabled: false,
	position: {
		my: "left top",
		at: "right top"
	}
};

commonWidgetTests('menu', { defaults: menu_defaults });
