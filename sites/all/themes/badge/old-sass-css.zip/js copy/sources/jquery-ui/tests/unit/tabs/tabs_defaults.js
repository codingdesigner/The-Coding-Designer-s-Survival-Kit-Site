commonWidgetTests( "tabs", {
	defaults: {
		activate: null,
		active: null,
		beforeLoad: null,
		beforeActivate: null,
		collapsible: false,
		disabled: false,
		event: "click",
		fx: null,
		load: null
	}
});
