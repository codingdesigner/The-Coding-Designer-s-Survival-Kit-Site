/*
 * tooltip_core.js
 */


(function($) {

module("tooltip: core");


})(jQuery);
