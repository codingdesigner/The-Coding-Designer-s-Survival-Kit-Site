// Function calls for Closure Compiler - prevents these functions from being removed

init();
cleanup();
