// Externs for Closure Compiler - prevents these functions from being renamed

function init(){};
function cleanup(){};
