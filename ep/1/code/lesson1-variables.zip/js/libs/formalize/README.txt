CREDITS

ExtJS port by Mike Wille:
https://github.com/digerata

MooTools port by Ryan Florence:
http://github.com/rpflorence

Helpful bug reports filed by:
http://github.com/wadewinningham
http://github.com/tingletech